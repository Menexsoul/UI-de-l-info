// Récupération des éléments DOM
const toggleModeBtn = document.getElementById('toggleMode');
const modeText = document.getElementById('modeText');
const statusText = document.getElementById('statusText');
const viewSitesBtn = document.getElementById('viewSites');
const resetCurrentBtn = document.getElementById('resetCurrent');
const resetAllBtn = document.getElementById('resetAll');
const currentSiteSpan = document.getElementById('currentSite');
const hiddenCountSpan = document.getElementById('hiddenCount');
const sitesCountSpan = document.getElementById('sitesCount');
const sitesList = document.getElementById('sitesList');

let currentDomain = '';
let isEditMode = false;

// Initialisation au chargement
document.addEventListener('DOMContentLoaded', async () => {
    await updateStats();
    loadSitesList();
});

// Activer/désactiver le mode édition
toggleModeBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    chrome.tabs.sendMessage(tab.id, { action: 'toggleEditMode' }, (response) => {
        if (response && response.isActive !== undefined) {
            isEditMode = response.isActive;
            updateModeUI(isEditMode);
        }
    });
});

// Mettre à jour l'interface du mode
function updateModeUI(active) {
    if (active) {
        modeText.textContent = '⏹ DÉSACTIVER MODE ÉDITION';
        toggleModeBtn.classList.add('active');
        statusText.textContent = 'MODE ÉDITION ACTIF';
    } else {
        modeText.textContent = '▶ ACTIVER MODE ÉDITION';
        toggleModeBtn.classList.remove('active');
        statusText.textContent = 'SYSTÈME PRÊT';
    }
}

// Voir/masquer la liste des sites
viewSitesBtn.addEventListener('click', () => {
    sitesList.classList.toggle('show');
    loadSitesList();
});

// Réinitialiser le site actuel
resetCurrentBtn.addEventListener('click', async () => {
    if (!currentDomain) return;
    
    if (confirm(`Voulez-vous réinitialiser tous les éléments masqués sur ${currentDomain} ?`)) {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        chrome.storage.local.get(['hiddenElements'], (result) => {
            const hiddenElements = result.hiddenElements || {};
            delete hiddenElements[currentDomain];
            
            chrome.storage.local.set({ hiddenElements }, () => {
                chrome.tabs.sendMessage(tab.id, { action: 'reloadPage' });
                updateStats();
                statusText.textContent = 'SITE RÉINITIALISÉ';
                setTimeout(() => statusText.textContent = 'SYSTÈME PRÊT', 2000);
            });
        });
    }
});

// Réinitialiser tous les sites
resetAllBtn.addEventListener('click', () => {
    if (confirm('⚠ ATTENTION : Voulez-vous vraiment supprimer TOUS les éléments masqués sur TOUS les sites ?')) {
        chrome.storage.local.set({ hiddenElements: {} }, async () => {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            chrome.tabs.sendMessage(tab.id, { action: 'reloadPage' });
            updateStats();
            loadSitesList();
            statusText.textContent = 'TOUT RÉINITIALISÉ';
            setTimeout(() => statusText.textContent = 'SYSTÈME PRÊT', 2000);
        });
    }
});

// Mettre à jour les statistiques
async function updateStats() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab || !tab.url) return;
    
    try {
        const url = new URL(tab.url);
        currentDomain = url.hostname;
        currentSiteSpan.textContent = currentDomain;
    } catch (e) {
        currentDomain = 'Unknown';
        currentSiteSpan.textContent = '--';
    }
    
    chrome.storage.local.get(['hiddenElements'], (result) => {
        const hiddenElements = result.hiddenElements || {};
        const sitesCount = Object.keys(hiddenElements).length;
        const currentHidden = hiddenElements[currentDomain]?.length || 0;
        
        sitesCountSpan.textContent = sitesCount;
        hiddenCountSpan.textContent = currentHidden;
    });
}

// Charger la liste des sites
function loadSitesList() {
    chrome.storage.local.get(['hiddenElements'], (result) => {
        const hiddenElements = result.hiddenElements || {};
        
        if (Object.keys(hiddenElements).length === 0) {
            sitesList.innerHTML = '<div style="padding: 20px; text-align: center; color: #666;">Aucun site nettoyé</div>';
            return;
        }
        
        let html = '';
        for (const [domain, selectors] of Object.entries(hiddenElements)) {
            html += `
                <div class="site-item">
                    <span class="site-url" title="${domain}">${domain}</span>
                    <span class="site-count">${selectors.length} élément(s)</span>
                    <button class="site-remove" data-domain="${domain}">✕</button>
                </div>
            `;
        }
        
        sitesList.innerHTML = html;
        
        // Ajouter les événements de suppression
        document.querySelectorAll('.site-remove').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const domain = e.target.dataset.domain;
                removeSite(domain);
            });
        });
    });
}

// Supprimer un site
function removeSite(domain) {
    chrome.storage.local.get(['hiddenElements'], (result) => {
        const hiddenElements = result.hiddenElements || {};
        delete hiddenElements[domain];
        
        chrome.storage.local.set({ hiddenElements }, () => {
            loadSitesList();
            updateStats();
        });
    });
}

// Écouter les messages du content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'updateStats') {
        updateStats();
    }
});