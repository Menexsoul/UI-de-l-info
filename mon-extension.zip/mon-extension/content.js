// État de l'extension
let isEditMode = false;
let hoveredElement = null;
let overlay = null;
let infoBox = null;

// Récupérer le domaine actuel
const currentDomain = window.location.hostname;

// Initialisation au chargement
document.addEventListener('DOMContentLoaded', () => {
    applyHiddenElements();
    createOverlay();
});

// Appliquer les éléments masqués au chargement
function applyHiddenElements() {
    chrome.storage.local.get(['hiddenElements'], (result) => {
        const hiddenElements = result.hiddenElements || {};
        const selectors = hiddenElements[currentDomain] || [];
        
        selectors.forEach(selector => {
            try {
                const elements = document.querySelectorAll(selector);
                elements.forEach(el => {
                    el.style.display = 'none';
                    el.setAttribute('data-vnr-hidden', 'true');
                });
            } catch (e) {
                console.error('Erreur lors de l\'application du sélecteur:', selector, e);
            }
        });
    });
}

// Créer l'overlay de sélection
function createOverlay() {
    // Overlay de surbrillance
    overlay = document.createElement('div');
    overlay.id = 'vnr-overlay';
    overlay.style.cssText = `
        position: absolute;
        pointer-events: none;
        border: 3px solid #00ff66;
        background: rgba(0, 255, 102, 0.1);
        z-index: 999999;
        display: none;
        box-shadow: 0 0 20px rgba(0, 255, 102, 0.5);
        transition: all 0.1s ease;
    `;
    document.body.appendChild(overlay);
    
    // Boîte d'information
    infoBox = document.createElement('div');
    infoBox.id = 'vnr-info-box';
    infoBox.style.cssText = `
        position: fixed;
        top: 10px;
        right: 10px;
        background: #121212;
        color: #00ff66;
        padding: 15px 20px;
        border: 2px solid #00ff66;
        font-family: 'Roboto Mono', monospace;
        font-size: 12px;
        z-index: 1000000;
        display: none;
        box-shadow: 0 0 30px rgba(0, 255, 102, 0.5);
        max-width: 300px;
    `;
    document.body.appendChild(infoBox);
}

// Activer/désactiver le mode édition
function toggleEditMode() {
    isEditMode = !isEditMode;
    
    if (isEditMode) {
        enableEditMode();
    } else {
        disableEditMode();
    }
    
    return isEditMode;
}

// Activer le mode édition
function enableEditMode() {
    infoBox.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 8px; text-shadow: 0 0 10px #00ff66;">
            🎯 MODE ÉDITION ACTIF
        </div>
        <div style="font-size: 11px; color: #e0e0e0; line-height: 1.5;">
            • Survolez un élément<br>
            • Cliquez pour masquer<br>
            • Échap pour quitter
        </div>
    `;
    infoBox.style.display = 'block';
    
    document.addEventListener('mouseover', handleMouseOver);
    document.addEventListener('mouseout', handleMouseOut);
    document.addEventListener('click', handleClick, true);
    document.addEventListener('keydown', handleKeyDown);
    
    document.body.style.cursor = 'crosshair';
}

// Désactiver le mode édition
function disableEditMode() {
    infoBox.style.display = 'none';
    overlay.style.display = 'none';
    
    document.removeEventListener('mouseover', handleMouseOver);
    document.removeEventListener('mouseout', handleMouseOut);
    document.removeEventListener('click', handleClick, true);
    document.removeEventListener('keydown', handleKeyDown);
    
    document.body.style.cursor = 'default';
}

// Gérer le survol
function handleMouseOver(e) {
    if (!isEditMode) return;
    
    // Ignorer l'overlay et l'infoBox
    if (e.target.id === 'vnr-overlay' || e.target.id === 'vnr-info-box' || e.target.closest('#vnr-info-box')) {
        return;
    }
    
    hoveredElement = e.target;
    highlightElement(hoveredElement);
}

// Gérer la sortie du survol
function handleMouseOut(e) {
    if (!isEditMode) return;
    overlay.style.display = 'none';
}

// Surligner un élément
function highlightElement(element) {
    const rect = element.getBoundingClientRect();
    
    overlay.style.display = 'block';
    overlay.style.top = `${rect.top + window.scrollY}px`;
    overlay.style.left = `${rect.left + window.scrollX}px`;
    overlay.style.width = `${rect.width}px`;
    overlay.style.height = `${rect.height}px`;
}

// Gérer le clic
function handleClick(e) {
    if (!isEditMode) return;
    
    e.preventDefault();
    e.stopPropagation();
    
    // Ignorer l'overlay et l'infoBox
    if (e.target.id === 'vnr-overlay' || e.target.id === 'vnr-info-box' || e.target.closest('#vnr-info-box')) {
        return;
    }
    
    hideElement(e.target);
}

// Gérer les touches
function handleKeyDown(e) {
    if (e.key === 'Escape') {
        isEditMode = false;
        disableEditMode();
        chrome.runtime.sendMessage({ action: 'editModeDisabled' });
    }
}

// Masquer un élément
function hideElement(element) {
    // Générer un sélecteur CSS unique
    const selector = generateSelector(element);
    
    // Masquer l'élément visuellement
    element.style.display = 'none';
    element.setAttribute('data-vnr-hidden', 'true');
    
    // Sauvegarder dans le storage
    chrome.storage.local.get(['hiddenElements'], (result) => {
        const hiddenElements = result.hiddenElements || {};
        
        if (!hiddenElements[currentDomain]) {
            hiddenElements[currentDomain] = [];
        }
        
        // Éviter les doublons
        if (!hiddenElements[currentDomain].includes(selector)) {
            hiddenElements[currentDomain].push(selector);
        }
        
        chrome.storage.local.set({ hiddenElements }, () => {
            showNotification(`✓ Élément masqué`);
            chrome.runtime.sendMessage({ action: 'updateStats' });
        });
    });
    
    overlay.style.display = 'none';
}

// Générer un sélecteur CSS unique
function generateSelector(element) {
    // Stratégie : utiliser l'ID, sinon la classe, sinon la position dans le DOM
    
    // 1. Essayer l'ID
    if (element.id) {
        return `#${CSS.escape(element.id)}`;
    }
    
    // 2. Essayer la classe (première classe seulement pour éviter les sélecteurs trop spécifiques)
    if (element.className && typeof element.className === 'string') {
        const firstClass = element.className.split(' ')[0];
        if (firstClass) {
            return `.${CSS.escape(firstClass)}`;
        }
    }
    
    // 3. Utiliser le chemin depuis le body
    const path = [];
    let current = element;
    
    while (current && current !== document.body) {
        let selector = current.tagName.toLowerCase();
        
        if (current.id) {
            selector += `#${CSS.escape(current.id)}`;
            path.unshift(selector);
            break;
        } else if (current.className && typeof current.className === 'string') {
            const classes = current.className.split(' ').filter(c => c).map(c => `.${CSS.escape(c)}`).join('');
            if (classes) {
                selector += classes;
            }
        }
        
        // Ajouter nth-child si nécessaire
        if (current.parentElement) {
            const siblings = Array.from(current.parentElement.children).filter(
                child => child.tagName === current.tagName
            );
            if (siblings.length > 1) {
                const index = siblings.indexOf(current) + 1;
                selector += `:nth-child(${index})`;
            }
        }
        
        path.unshift(selector);
        current = current.parentElement;
    }
    
    return path.join(' > ');
}

// Afficher une notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 10px;
        background: #121212;
        color: #00ff66;
        padding: 12px 20px;
        border: 2px solid #00ff66;
        font-family: 'Roboto Mono', monospace;
        font-size: 13px;
        z-index: 1000001;
        box-shadow: 0 0 20px rgba(0, 255, 102, 0.5);
        animation: slideIn 0.3s ease;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 2000);
}

// Écouter les messages de la popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'toggleEditMode') {
        const active = toggleEditMode();
        sendResponse({ isActive: active });
    } else if (message.action === 'reloadPage') {
        window.location.reload();
    }
    return true;
});

// Styles CSS pour les animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);